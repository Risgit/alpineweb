<?php

class UI extends UIBase
{

    public static function PrintConfPage($disp, $page)
    {
        $ui = new UI();
        $ui->print_conf_page($disp, $page);
    }

}

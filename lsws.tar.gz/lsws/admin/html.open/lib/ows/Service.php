<?php

class Service extends ControllerBase
{
}

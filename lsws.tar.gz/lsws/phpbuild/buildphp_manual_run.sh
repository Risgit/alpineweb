#!/bin/sh

###########################################
#	Please manually run this script after preparation finished successfully.
#	You can monitor the log output from web console.
#	You need to run as root or with root privilege in order to install into system directory.
###########################################

INSTALL_SCRIPT=/usr/local/lsws/phpbuild/buildphp_1623828083.3.install.sh
LOG_FILE=/usr/local/lsws/phpbuild/buildphp_1623828083.3.log
PHP_VERSION=8.0.1
PHP_BUILD_DIR=/usr/local/lsws/phpbuild
PHP_USR=nobody
PHP_USRGROUP=nobody


echo "Manually running installation script: ${INSTALL_SCRIPT}"
echo "Running at background with command:"
echo "${INSTALL_SCRIPT} 1> ${LOG_FILE} 2>&1"

${INSTALL_SCRIPT} 1> ${LOG_FILE} 2>&1

INST_USER=`id`
INST_USER=`expr "${INST_USER}" : 'uid=.*(\(.*\)) gid=.*'`

if [  "x${INST_USER}" = "xroot" ]; then
    echo "chown -R ${PHP_USR}:${PHP_USRGROUP} ${PHP_BUILD_DIR}/php-${PHP_VERSION}"
    chown -R ${PHP_USR}:${PHP_USRGROUP} ${PHP_BUILD_DIR}/php-${PHP_VERSION} 
fi

if [ -f "/etc/cagefs/cagefs.mp" ] ; then
# cagefs installed first, need update mount point
    cagefsctl --update
fi

<?php

require_once('global.php');

CAuthorizer::Authorize();
